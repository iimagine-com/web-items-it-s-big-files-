import React, { useContext } from 'react';


const Login = () => {
    return (
        <div>
            <h1>This is Login</h1>
        </div>
    );
};

export default Login;