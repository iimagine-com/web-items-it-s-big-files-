import React from 'react';


const PatientReducer = () => {



    return (
        <div>
            <h1>Manage Doctor Chamber </h1>
        </div>
    );
};

export default PatientReducer;